# Spaceship Boss Battle

## **Control**:
Up - Move up\
Down - Move down\
Right - Move to right\
Left - Move to left\
A - Shoot a Laser\
Start - Start a Game\
Select - Pause a Game

## **GOAL**:
Your goal is to destroy the enemy spaceship by shooting lasers at it. You will win when the Boss HP gets to 0, and you will lose when you get hit by the enemy bomb that chases you for 3 times. 

## **State Navigation**:
You will start of with a *Start* state. Press start button to move to the *Game* state. While in the *Game* state, press select button to move to the *Pause* state. When you win the game (destroy the boss spaceship), you will automatically move to the *Win* state. If you lose all of your lives, you will be sent to the *Lose* state. 