#include "gba.h"
#include "font.h"
#include "player.h"
#include "print.h"
#include "enemy.h"

void initPlayer() {
    player.x = 115;
    player.y = 150;
    player.oldx = 0;
    player.oldy = 0;
    player.width = 9;
    player.height = 10;
    player.xVel = 2;
    player.yVel = 2;
    player.color = WHITE;
}

void updatePlayer() {
    player.oldx = player.x;
    player.oldy = player.y;

    if (BUTTON_PRESSED(BUTTON_A)) {
        newLaser(player.x + 4, player.y - 4, 0, 2);
    }
    
    if (BUTTON_HELD(BUTTON_UP) && player.y > 34 && !collision(player.x, player.y - player.yVel, player.width, player.height, boss.x, boss.y, boss.width, boss.height) && !collision(player.x, player.y - player.yVel, player.width, player.height, boss1.x, boss1.y, boss1.width, boss1.height) && !collision(player.x, player.y - player.yVel, player.width, player.height, boss2.x, boss2.y, boss2.width, boss2.height)) {
        player.y -= player.yVel; 
    } else if (BUTTON_HELD(BUTTON_DOWN) && player.y < SCREENHEIGHT - player.height && !collision(player.x, player.y - player.yVel, player.width, player.height, boss1.x, boss1.y, boss1.width, boss1.height) && !collision(player.x, player.y - player.yVel, player.width, player.height, boss2.x, boss2.y, boss2.width, boss2.height)) {
        player.y += player.yVel;
    }

    if (BUTTON_HELD(BUTTON_RIGHT) && player.x < SCREENWIDTH - player.width && !collision(player.x + player.xVel, player.y, player.width, player.height, boss.x, boss.y, boss.width, boss.height) && !collision(player.x + player.xVel, player.y, player.width, player.height, boss1.x, boss1.y, boss1.width, boss1.height) && !collision(player.x + player.xVel, player.y, player.width, player.height, boss2.x, boss2.y, boss2.width, boss2.height)) {
        player.x += player.xVel;
    } else if (BUTTON_HELD(BUTTON_LEFT) && player.x > 25 && !collision(player.x - player.xVel, player.y, player.width, player.height, boss.x, boss.y, boss.width, boss.height) && !collision(player.x - player.xVel, player.y, player.width, player.height, boss1.x, boss1.y, boss1.width, boss1.height) && !collision(player.x - player.xVel, player.y, player.width, player.height, boss2.x, boss2.y, boss2.width, boss2.height)) {
        player.x -= player.xVel;
    } 

    for (int i = 0; i < ENEMYCOUNT; ++i) {
        if (collision(player.x, player.y, player.width, player.height, enemy.x, enemy.y, enemy.width, enemy.height)) {
            lifeCount--;
            enemy.x = 117;
            enemy.y = 40;
            enemyCollision = 1;
        }
    }
}

void drawPlayer() {
    if (enemyCollision == 1) {
        drawRectangle(player.oldx - 1, player.oldy - 1, player.width + 2, player.height + 2, BLACK);
    }
    drawRectangle(player.oldx, player.oldy, player.width, player.height, BLACK);
    drawRectangle(player.x, player.y, player.width, player.height, player.color);
}

void initLaser() {
    for (int i = 0; i < LASERCOUNT; ++i) {
        lasers[i].x = 0;
        lasers[i].y = 0;
        lasers[i].oldx = 0;
        lasers[i].oldy = 0;
        lasers[i].width = 1;
        lasers[i].height = 3;
        lasers[i].xVel = 0;
        lasers[i].yVel = 2;
        lasers[i].color = LASERCOLOR;
        lasers[i].active = 0;
    }
}

void updateLaser() {
    
    for (int i = 0; i < LASERCOUNT; ++i) {
        if (lasers[i].active) {
            lasers[i].oldy = lasers[i].y;
            if (lasers[i].y > 16 && !collision(lasers[i].x, lasers[i].y - lasers[i].yVel, lasers[i].width, lasers[i].height, boss.x, boss.y, boss.width, boss.height) && !collision(lasers[i].x, lasers[i].y - lasers[i].yVel, lasers[i].width, lasers[i].height, boss1.x, boss1.y, boss1.width, boss1.height) && !collision(lasers[i].x, lasers[i].y - lasers[i].yVel, lasers[i].width, lasers[i].height, boss2.x, boss2.y, boss2.width, boss2.height)) {
                lasers[i].y -= lasers[i].yVel;
            } else {
                lasers[i].active = 0;
                if (collision(lasers[i].x, lasers[i].y - lasers[i].yVel, lasers[i].width, lasers[i].height, boss.x, boss.y, boss.width, boss.height) || collision(lasers[i].x, lasers[i].y - lasers[i].yVel, lasers[i].width, lasers[i].height, boss1.x, boss1.y, boss1.width, boss1.height) || collision(lasers[i].x, lasers[i].y - lasers[i].yVel, lasers[i].width, lasers[i].height, boss2.x, boss2.y, boss2.width, boss2.height)) {
                    bossLifeManger++;
                    mgba_printf("bossLifeManager: %d", bossLifeManger);
                }
            }
        }
    }
}

void drawLaser() {
    for (int i = 0; i < LASERCOUNT; ++i) {
        if (lasers[i].active) {
            drawRectangle(lasers[i].x, lasers[i].oldy, lasers[i].width, lasers[i].height, BLACK);
            drawRectangle(lasers[i].x, lasers[i].y, lasers[i].width, lasers[i].height, LASERCOLOR);
        } else {
            drawRectangle(lasers[i].oldx, lasers[i].oldy, lasers[i].width, lasers[i].height, BLACK);
            drawRectangle(lasers[i].x, lasers[i].y, lasers[i].width, lasers[i].height, BLACK);    
        }
    }
}

void newLaser(int x, int y, int xVel, int yVel) {
    for (int i = 0; i < LASERCOUNT; ++i) {
        if (!lasers[i].active) {
            lasers[i].active = 1;
            lasers[i].x = x;
            lasers[i].y = y;
            lasers[i].xVel = xVel;
            lasers[i].yVel = yVel;
        }
    }
}

void initLife() {
    for (int i = 0; i < LIFECOUNT; ++i) {
        life[i].x = 205 + (10 * i);
        life[i].y = 5;
        life[i].width = player.width;
        life[i].height = player.height;
        life[i].color = player.color;
    }
}

void updateLife() {
    for (int i = LIFECOUNT - 1; i >= 0; i--) {
        if (lifeCount == i) {
            life[i].color = BLACK;
        } 
    }  
}

void drawLife() {
    for (int i = 0; i < LIFECOUNT; ++i) {
        drawRectangle(life[i].x, life[i].y, player.width, life[i].height, life[i].color);
    }
}
