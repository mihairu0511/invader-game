#ifndef ENEMY_H
#define ENEMY_H

int bossLife;
int bossLifeManger;
int enemyCollision;

typedef struct {
    int x;
    int y;
    int oldx;
    int oldy;
    int width;
    int height;
    int xVel;
    int yVel;
    unsigned short color;
} ENEMY;

#define ENEMYCOUNT 3

ENEMY enemy;

typedef struct {
    int x;
    int y;
    int width;
    int height;
    unsigned short color;
} BOSSHP;

typedef struct {
    int x;
    int y;
    int width;
    int height;
} BOSS;

BOSS boss;
BOSS boss1;
BOSS boss2;

#define BOSSHPCOUNT 20

BOSSHP bossHP[BOSSHPCOUNT];

void initEnemy();
void updateEnemy();
void drawEnemy();

void initBossHP();
void updateBossHP();
void updateBossLife();
void drawBossHP();
void initBoss();
void drawBoss();

#endif 