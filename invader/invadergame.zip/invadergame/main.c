#include "gba.h"
#include "print.h"
#include "player.h"
#include "enemy.h"

// Function Prototypes
void initialize();
void updateGame();
void drawGame();

void goToStart();
void goToPause();
void goToGame();
void goToWin();
void goToLose();

unsigned short buttons;
unsigned short oldButtons;

enum STATE {START, PAUSE, GAME, WIN, LOSE} state;

int main() {

    initialize();

    while (1) {

        oldButtons = buttons;
        buttons = REG_BUTTONS;

        switch (state) {
            case START:
                if (BUTTON_PRESSED(BUTTON_START)) {
                    initialize();
                    goToGame();
                }
                break;

            case PAUSE:
                if (BUTTON_PRESSED(BUTTON_SELECT)) {
                    goToGame();
                }
                break;

            case GAME:
                updateGame();
                waitForVBlank();
                drawGame();
                if (BUTTON_PRESSED(BUTTON_SELECT)) {
                    goToPause();
                }
                if (lifeCount == 0) {
                    goToLose();
                }
                if (bossLife == BOSSHPCOUNT - 1) {
                    goToWin();
                }
                break;

            case WIN:
                if (BUTTON_PRESSED(BUTTON_START)) {
                    goToStart();
                }
                break;

            case LOSE:
                if (BUTTON_PRESSED(BUTTON_START)) {
                    goToStart();
                }
                break;
        }
    }
    return 0;
}

void initialize() {
    mgba_open();

    REG_DISPCTL = MODE(3) | BG2_ENABLE;

    oldButtons = 0;
	buttons = REG_BUTTONS;

    lifeCount = 3;
    bossLife = -1;
    bossLifeManger = 0;
    enemyCollision = 0;

    initPlayer();
    initLaser();
    initLife();
    initBossHP();
    initBoss();
    initEnemy();

    goToStart();
}

void updateGame() {
    enemyCollision = 0;
    updatePlayer();
    updateLaser();
    updateLife();
    updateBossLife();
    updateBossHP();
    updateEnemy();
}

void drawGame() {
    drawEnemy();
    drawPlayer();
    drawLaser();
    drawLife();
    drawBossHP();
}

void goToStart() {
    fillScreen(BLACK);
    drawString(88, 80, "PRESS START", WHITE);
    state = START;
}

void goToPause() {
    fillScreen(BLACK);
    drawString(105, 80, "PAUSE", WHITE);
    state = PAUSE;
}

void goToGame() {
    fillScreen(BLACK);

    drawString(175, 7, "LIFE:", YELLOW);
    drawString(1, 10, "BOSS", RED);
    drawString(7, 20, "HP", RED);
    drawRectangle(9, 31, 8, 122, WHITE);
    drawRectangle(10, 32, 6, 120, BLACK);
    
    drawBoss();

    drawLife();
    state = GAME;

}

void goToWin() {
    fillScreen(BLACK);
    drawString(95, 80, "You WIN!", WHITE);
    state = WIN;
}

void goToLose() {
    fillScreen(BLACK);
    drawString(95, 80, "GAMEOVER", WHITE);
    state = LOSE;
}