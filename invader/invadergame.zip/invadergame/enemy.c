#include "gba.h"
#include "font.h"
#include "enemy.h"
#include "print.h"
#include "player.h"

void initEnemy() {
    for (int i = 0; i < ENEMYCOUNT; ++i) {
        enemy.x = 117;
        enemy.y = 40;
        enemy.oldx = 0;
        enemy.oldy =0;
        enemy.width = 2;
        enemy.height = 2;
        enemy.xVel = 1;
        enemy.yVel = 1;
        enemy.color = YELLOW;
    }
}

void updateEnemy() {

    enemy.oldx = enemy.x;
    enemy.oldy = enemy.y;

    if (enemy.x < player.x) {
        enemy.x += enemy.xVel;
    }
    if (enemy.x > player.x) {
        enemy.x -= enemy.xVel;
    }
    if (enemy.y < player.y) {
        enemy.y += enemy.yVel;
    }
    if (enemy.y > player.y) {
        enemy.y -= enemy.yVel;
    }
}

void drawEnemy() {
    for (int i = 0; i < ENEMYCOUNT; ++i) {
        drawRectangle(enemy.oldx, enemy.oldy, enemy.width, enemy.height, BLACK);
        drawRectangle(enemy.x, enemy.y, enemy.width, enemy.height, enemy.color);
    }
}

void initBossHP() {
    for (int i = 0; i < BOSSHPCOUNT; ++i) {
        bossHP[i].x = 10;
        bossHP[i].y = 32 + (6 * i);
        bossHP[i].width = 6;
        bossHP[i].height = 6;
        bossHP[i].color = RED;
    }
}

void updateBossHP() {
    for (int i = 0; i < BOSSHPCOUNT; ++i) {
        if (bossLife == i) {
            bossHP[i].color = BLACK;
        }
    }  
}

void updateBossLife() {
    if (bossLifeManger == 10) {
        bossLife++;
        bossLifeManger = 0;
    }
}

void drawBossHP() {
    for (int i = 0; i < BOSSHPCOUNT; ++i) {
        drawRectangle(bossHP[i].x, bossHP[i].y, bossHP[i].width, bossHP[i].height, bossHP[i].color);
    }
}

void initBoss() {
    boss.x = 87;
    boss.y = 2;
    boss.width = 61;
    boss.height = 32;

    boss1.x = 79;
    boss1.y = 2;
    boss1.width = 77;
    boss1.height = 26;

    boss2.x = 70;
    boss2.y = 2;
    boss2.width = 95;
    boss2.height = 22;

}

void drawBoss() {
    //
    drawRectangle(74, 2, 87, 1, DARKGRAY);
    drawRectangle(73, 3, 89, 1, DARKGRAY);
    drawRectangle(72, 4, 91, 1, DARKGRAY);
    drawRectangle(71, 5, 93, 1, DARKGRAY);
    drawRectangle(70, 6, 95, 9, DARKGRAY);
    drawRectangle(71, 15, 93, 1, DARKGRAY);
    drawRectangle(72, 16, 91, 2, DARKGRAY);
    for (int i = 0; i < 7; ++i) {
        drawRectangle(73 + i, 18 + i, 89 - (2 * i), 1, DARKGRAY);
    }
    for (int i = 0; i < 4; ++i) {
        drawRectangle(81 + 2 * i, 25 + i, 73 - (4 * i), 1, DARKGRAY);
    }
    drawRectangle(90, 29, 55, 1, DARKGRAY);
    drawRectangle(93, 30, 49, 1, DARKGRAY);
    drawRectangle(96, 31, 43, 1, RED);
    drawRectangle(101, 32, 33, 1, RED);
    drawRectangle(107, 33, 21, 1, RED);
    //
    
    drawRectangle(92, 10, 5, 1, GRAY);
    drawRectangle(90, 11, 2, 1, GRAY);
    drawRectangle(97, 11, 2, 1, GRAY);
    drawRectangle(89, 12, 1, 1, GRAY);
    drawRectangle(99, 12, 1, 1, GRAY);
    drawRectangle(88, 13, 1, 1, GRAY);
    drawRectangle(100, 13, 1, 1, GRAY);
    drawRectangle(87, 14, 1, 2, GRAY);
    drawRectangle(101, 14, 1, 2, GRAY);
    drawRectangle(86, 16, 1, 5, GRAY);
    drawRectangle(102, 16, 1, 5, GRAY);
    drawRectangle(87, 21, 1, 2, GRAY);
    drawRectangle(101, 21, 1, 2, GRAY);
    drawRectangle(88, 23, 1, 1, GRAY);
    drawRectangle(100, 23, 1, 1, GRAY);
    drawRectangle(89, 24, 1, 1, GRAY);
    drawRectangle(99, 24, 1, 1, GRAY);
    drawRectangle(90, 25, 2, 1, GRAY);
    drawRectangle(97, 25, 2, 1, GRAY);
    drawRectangle(92, 26, 5, 1, GRAY);

    drawRectangle(92 + 46, 10, 5, 1, GRAY);
    drawRectangle(90 + 46, 11, 2, 1, GRAY);
    drawRectangle(97 + 46, 11, 2, 1, GRAY);
    drawRectangle(89 + 46, 12, 1, 1, GRAY);
    drawRectangle(99 + 46, 12, 1, 1, GRAY);
    drawRectangle(88 + 46, 13, 1, 1, GRAY);
    drawRectangle(100 + 46, 13, 1, 1, GRAY);
    drawRectangle(87 + 46, 14, 1, 2, GRAY);
    drawRectangle(101 + 46, 14, 1, 2, GRAY);
    drawRectangle(86 + 46, 16, 1, 5, GRAY);
    drawRectangle(102 + 46, 16, 1, 5, GRAY);
    drawRectangle(87 + 46, 21, 1, 2, GRAY);
    drawRectangle(101 + 46, 21, 1, 2, GRAY);
    drawRectangle(88 + 46, 23, 1, 1, GRAY);
    drawRectangle(100 + 46, 23, 1, 1, GRAY);
    drawRectangle(89 + 46, 24, 1, 1, GRAY);
    drawRectangle(99 + 46, 24, 1, 1, GRAY);
    drawRectangle(90 + 46, 25, 2, 1, GRAY);
    drawRectangle(97 + 46, 25, 2, 1, GRAY);
    drawRectangle(92 + 46, 26, 5, 1, GRAY);

    drawRectangle(93, 14, 3, 1, BLACK);
    drawRectangle(92, 15, 1, 1, BLACK);
    drawRectangle(96, 15, 1, 1, BLACK);
    drawRectangle(91, 15, 1, 2, BLACK);
    drawRectangle(97, 15, 1, 2, BLACK);
    drawRectangle(90, 17, 1, 3, BLACK);
    drawRectangle(98, 17, 1, 3, BLACK);
    drawRectangle(91, 20, 1, 2, BLACK);
    drawRectangle(97, 20, 1, 2, BLACK);
    drawRectangle(92, 21, 1, 1, BLACK);
    drawRectangle(96, 21, 1, 1, BLACK);
    drawRectangle(93, 22, 3, 1, BLACK);

    drawRectangle(93 + 46, 14, 3, 1, BLACK);
    drawRectangle(92 + 46, 15, 1, 1, BLACK);
    drawRectangle(96 + 46, 15, 1, 1, BLACK);
    drawRectangle(91 + 46, 15, 1, 2, BLACK);
    drawRectangle(97 + 46, 15, 1, 2, BLACK);
    drawRectangle(90 + 46, 17, 1, 3, BLACK);
    drawRectangle(98 + 46, 17, 1, 3, BLACK);
    drawRectangle(91 + 46, 20, 1, 2, BLACK);
    drawRectangle(97 + 46, 20, 1, 2, BLACK);
    drawRectangle(92 + 46, 21, 1, 1, BLACK);
    drawRectangle(96 + 46, 21, 1, 1, BLACK);
    drawRectangle(93 + 46, 22, 3, 1, BLACK);

    drawRectangle(93, 15, 3, 7, RED);
    drawRectangle(92, 16, 5, 5, RED);
    drawRectangle(91, 17, 7, 3, RED);

    drawRectangle(93 + 46, 15, 3, 7, RED);
    drawRectangle(92 + 46, 16, 5, 5, RED);
    drawRectangle(91 + 46, 17, 7, 3, RED);
}