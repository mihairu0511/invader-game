// The array of character data
extern const unsigned char fontdata[12288];