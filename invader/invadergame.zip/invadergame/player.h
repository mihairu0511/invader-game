#ifndef PLAYER_H
#define PLAYER_H

int lifeCount;

typedef struct {
    int x;
    int y;
    int oldx;
    int oldy;
    int width;
    int height;
    int xVel;
    int yVel;
    unsigned short color;
} PLAYER;

PLAYER player;

typedef struct {
    int x;
    int y;
    int oldx;
    int oldy;
    int width;
    int height;
    int xVel;
    int yVel;
    unsigned short color;
    int active;
} LASER;

#define LASERCOUNT 10
#define LASERCOLOR RED

LASER lasers[LASERCOUNT];

typedef struct{
    int x;
    int y;
    int width;
    int height;
    unsigned short color;
} LIFE;

#define LIFECOUNT 3

LIFE life[LIFECOUNT];

void initPlayer();
void updatePlayer();
void drawPlayer();

void initLaser();
void updateLaser();
void drawLaser();
void newLaser();

void deleteLife();
void initLife();
void updateLife();
void drawLife();

#endif 